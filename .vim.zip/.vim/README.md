.vim
====

Vim plugins and vimrc
